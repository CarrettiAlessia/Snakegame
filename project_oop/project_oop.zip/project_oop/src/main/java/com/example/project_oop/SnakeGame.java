package com.example.project_oop;

public class SnakeGame {
    public static void main(String[] args) {
        new GameFrame();
    }
}
